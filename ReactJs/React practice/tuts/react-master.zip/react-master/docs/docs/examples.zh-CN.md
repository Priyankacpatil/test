---
id: examples-zh-CN
title: 示例
permalink: examples-zh-CN.html
prev: complementary-tools-zh-CN.html
---

本页被移到了 [GitHub wiki](https://github.com/facebook/react/wiki/Examples)。
