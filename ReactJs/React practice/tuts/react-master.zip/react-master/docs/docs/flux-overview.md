---
id: flux-overview
title: Flux Application Architecture
permalink: flux-overview.html
---

This page has been moved to the Flux website. [View it there](https://facebook.github.io/flux/docs/overview.html).
