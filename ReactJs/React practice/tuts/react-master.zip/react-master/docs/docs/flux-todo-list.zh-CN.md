---
id: flux-todo-list-zh-CN
title: Flux TodoMVC 教程
permalink: flux-todo-list-zh-CN.html
---

本页被移到了 Flux 网站。[点击访问](https://facebook.github.io/flux/docs/todo-list.html)。
