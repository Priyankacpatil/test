---
id: references-to-components-ko-KR
title: 컴포넌트 참조
layout: tips
permalink: references-to-components-ko-KR.html
prev: expose-component-functions-ko-KR.html
next: children-undefined-ko-KR.html
---

이 페이지는 이동되었습니다. [refs](/react/docs/more-about-refs-ko-KR.html)
